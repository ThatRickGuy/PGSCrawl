﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows;
using PGSwiss.Data;

namespace PGSCrawl
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Net.WebClient wc = new System.Net.WebClient();
            string webData = wc.DownloadString("http://ringdev.com/swiss/standings/default.aspx");

            var links = new List<string>();
            var linkChunks = webData.Split(new string[] { "<a href=" }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var linkChunk in linkChunks)
                if (linkChunk.Contains(".html"))
                    links.Add("http://ringdev.com/swiss/standings/" + linkChunk.Split(new string[] { "." }, StringSplitOptions.RemoveEmptyEntries)[0].Remove(0, 1) + ".xml");

            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "trgguidtest.database.windows.net,1433";
            builder.UserID = "thatrickguy";
            builder.Password = "Sulton24!";
            builder.InitialCatalog = "GUIDTest";
            using (SqlConnection conn = new SqlConnection(builder.ConnectionString))
            {
                conn.Open();
                string insert = "INSERT INTO PGSCrawl(EventDate,  GameID, Winner, Condition, Scenario, Length, Faction, CP, APD, OpponentFaction, OpponentCP, OpponentAPD) values " +
                                                    "(@EventDate,@GameID,@Winner,@Condition,@Scenario,@Length,@Faction,@CP,@APD,@OpponentFaction,@OpponentCP,@OpponentAPD) ";


                if (File.Exists("output.csv"))
                    File.Delete("output.csv");
                File.WriteAllText("output.csv", "Event Date,Game ID,Winner,Condition,Scenario,Length,Faction,CP,APD,Opponent Faction,Opponent CP,Opponent APD");
                foreach (var link in links)
                {
                    try
                    {
                        webData = wc.DownloadString(link);

                        File.WriteAllText("temp.xml", webData);
                        var wmevent = new doWMEvent("temp.xml");

                        if ("2017 Steam Roller, 2018 Masters, 2018 Steamroller, 2017 Steamroller,2017 Masters,2017 Champions".Contains(wmevent.EventFormat.Name)
                            && wmevent.EventID.ToString() != "2a8107d1-3bfd-4df7-a031-a9468c630ba3"
                            && wmevent.EventID.ToString() != "e3448557-62cb-4f71-942a-2f65a1297e44"
                            && wmevent.EventID.ToString() != "dde7460c-c544-48d6-b19f-da9d8be33e18"
                            )
                        {
                            if (wmevent.Rounds.Count > 2)
                                foreach (var rnd in wmevent.Rounds)
                                    foreach (var game in rnd.Games)
                                    {
                                        if (game.Player2 != null)
                                        {
                                            var sOutL1 = wmevent.EventDate + "," + game.GameID + "," + (game.Winner == game.Player1.Name) + "," + game.Condition + "," + game.Scenario + "," + game.GameLength + "," +
                                                         game.Player1.Faction + "," + game.Player1.ControlPoints + "," + game.Player1.ArmyPointsDestroyed + "," +
                                                         game.Player2.Faction + "," + game.Player2.ControlPoints + "," + game.Player2.ArmyPointsDestroyed + "\r\n";
                                            var sOutL2 = wmevent.EventDate + "," + game.GameID + "," + (game.Winner == game.Player2.Name) + "," + game.Condition + "," + game.Scenario + "," + game.GameLength + "," +
                                                         game.Player2.Faction + "," + game.Player2.ControlPoints + "," + game.Player2.ArmyPointsDestroyed + "," +
                                                         game.Player1.Faction + "," + game.Player1.ControlPoints + "," + game.Player1.ArmyPointsDestroyed + "\r\n";
                                            File.AppendAllText("output.csv", sOutL1);
                                            File.AppendAllText("output.csv", sOutL2);

                                            using (SqlCommand command = new SqlCommand(insert, conn))
                                            {
                                                command.Parameters.Add("@EventDate", SqlDbType.Date).Value = wmevent.EventDate;
                                                command.Parameters.Add("@GameID", SqlDbType.VarChar).Value = game.GameID.ToString();
                                                command.Parameters.Add("@Winner", SqlDbType.VarChar).Value = (game.Winner == game.Player1.Name);
                                                command.Parameters.Add("@Condition", SqlDbType.VarChar).Value = (game.Condition == null) ? "" : game.Condition;
                                                command.Parameters.Add("@Scenario", SqlDbType.VarChar).Value = (game.Scenario == null) ? "" : game.Scenario;
                                                command.Parameters.Add("@Length", SqlDbType.TinyInt).Value = (game.GameLength == null) ? 0 : game.GameLength;
                                                command.Parameters.Add("@Faction", SqlDbType.VarChar).Value = (game.Player1.Faction == null) ? "" : game.Player1.Faction;
                                                command.Parameters.Add("@CP", SqlDbType.TinyInt).Value = game.Player1.ControlPoints;
                                                command.Parameters.Add("@APD", SqlDbType.TinyInt).Value = game.Player1.ArmyPointsDestroyed;
                                                command.Parameters.Add("@OpponentFaction", SqlDbType.VarChar).Value = (game.Player2.Faction == null) ? "" : game.Player2.Faction;
                                                command.Parameters.Add("@OpponentCP", SqlDbType.TinyInt).Value = game.Player2.ControlPoints;
                                                command.Parameters.Add("@OpponentAPD", SqlDbType.TinyInt).Value = game.Player2.ArmyPointsDestroyed;
                                                command.ExecuteNonQuery();
                                            }
                                            using (SqlCommand command = new SqlCommand(insert, conn))
                                            {
                                                command.Parameters.Add("@EventDate", SqlDbType.Date).Value = wmevent.EventDate;
                                                command.Parameters.Add("@GameID", SqlDbType.VarChar).Value = game.GameID.ToString();
                                                command.Parameters.Add("@Winner", SqlDbType.VarChar).Value = (game.Winner == game.Player2.Name);
                                                command.Parameters.Add("@Condition", SqlDbType.VarChar).Value = (game.Condition == null) ? "" : game.Condition;
                                                command.Parameters.Add("@Scenario", SqlDbType.VarChar).Value = (game.Scenario == null) ? "" : game.Scenario;
                                                command.Parameters.Add("@Length", SqlDbType.TinyInt).Value = (game.GameLength == null) ? 0 : game.GameLength;
                                                command.Parameters.Add("@Faction", SqlDbType.VarChar).Value = (game.Player2.Faction == null) ? "" : game.Player2.Faction;
                                                command.Parameters.Add("@CP", SqlDbType.TinyInt).Value = game.Player2.ControlPoints;
                                                command.Parameters.Add("@APD", SqlDbType.TinyInt).Value = game.Player2.ArmyPointsDestroyed;
                                                command.Parameters.Add("@OpponentFaction", SqlDbType.VarChar).Value = (game.Player1.Faction == null) ? "" : game.Player1.Faction;
                                                command.Parameters.Add("@OpponentCP", SqlDbType.TinyInt).Value = game.Player1.ControlPoints;
                                                command.Parameters.Add("@OpponentAPD", SqlDbType.TinyInt).Value = game.Player1.ArmyPointsDestroyed;
                                                command.ExecuteNonQuery();
                                            }
                                        }
                                    }
                        }
                        else if ("Other, Highlander".Contains(wmevent.EventFormat.Name))
                        { // known format we don't care about
                        }
                        else
                        {
                            //MessageBox.Show("Unknown Format: " + wmevent.EventFormat.Name);
                        }
                    }
                    catch (System.Net.WebException exc)
                    {
                        //xml not found
                    }
                }

            }



        }
    }
}
